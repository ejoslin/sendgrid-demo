const sendgrid = require('sendgrid');
const config = require('./config.json');
const uuid = require('uuid');

// Get a reference to the Cloud Storage component
const {Storage} = require('@google-cloud/storage');
const storage = new Storage();
// Get a reference to the BigQuery component
const {BigQuery} = require('@google-cloud/bigquery');
const bigquery = new BigQuery();

// [START functions_sendgrid_get_table]
/**
 * Helper method to get a handle on a BigQuery table. Automatically creates the
 * dataset and table if necessary.
 */
const getTable = async () => {
  let dataset = bigquery.dataset(config.DATASET);

  [dataset] = await dataset.get({autoCreate: true});
  return dataset.table(config.TABLE).get({autoCreate: true});
};
// [END functions_sendgrid_get_table]

// [START functions_sendgrid_load]
/**
 * Cloud Function triggered by Cloud Storage when a file is uploaded.
 *
 * @param {object} event The Cloud Functions event.
 * @param {object} event.data A Cloud Storage file object.
 * @param {string} event.data.bucket Name of the Cloud Storage bucket.
 * @param {string} event.data.name Name of the file.
 * @param {string} [event.data.timeDeleted] Time the file was deleted if this is a deletion event.
 * @see https://cloud.google.com/storage/docs/json_api/v1/objects#resource
 */
exports.sendgridLoad = async event => {
  const file = event;

  if (file.resourceState === 'not_exists') {
    // This was a deletion event, we don't want to process this
    return;
  }

  try {
    if (!file.bucket) {
      throw new Error(
        'Bucket not provided. Make sure you have a "bucket" property in your request'
      );
    } else if (!file.name) {
      throw new Error(
        'Filename not provided. Make sure you have a "name" property in your request'
      );
    }

    const [table] = await getTable();

    const fileObj = storage.bucket(file.bucket).file(file.name);
    console.log(`Starting job for ${file.name}`);
    const metadata = {
      autodetect: true,
      sourceFormat: 'NEWLINE_DELIMITED_JSON',
    };
    const [job] = await table.load(fileObj, metadata );

    await job;
    console.log(`Job complete for ${file.name}`);
  } catch (err) {
    console.log(`Job failed for ${file.name}`);
    return Promise.reject(err);
  }
};
// [END functions_sendgrid_load]
